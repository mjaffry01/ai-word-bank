import os
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from openai import OpenAI, APIError, RateLimitError
from pydantic import BaseModel, ConfigDict, Field

app = FastAPI()
ROOT = Path(__file__).resolve().parent
MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
MAX_CONTEXT_CHARS = 24_000
INSTRUCTIONS = """
You are an AI concepts tutor for beginners.
Explain one idea at a time, use a short example, and usually stay under
200 words. Say when you are uncertain. Ask for clarification when needed.
You cannot browse, read the student's website, or access private records.
Do not invent course policies, deadlines, grades, or account status.
If a course-specific answer needs material you lack, say so.
Do not claim you used a source or took an action unless it was provided.
""".strip()


class Message(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=8_000)


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    message: str = Field(min_length=1, max_length=2_000)
    history: list[Message] = Field(default_factory=list, max_length=8)


@app.get("/")
def home():
    return FileResponse(ROOT / "index.html")


@app.post("/chat")
def chat(body: ChatRequest):
    # This demo accepts complete user/assistant pairs only.
    history = [item.model_dump() for item in body.history]
    if len(history) % 2 or any(
        item["role"] != ("user" if i % 2 == 0 else "assistant")
        for i, item in enumerate(history)
    ):
        raise HTTPException(400, "History must contain complete exchanges.")

    # Drop oldest complete pairs; keep instructions and the new question.
    while history and (
        sum(len(item["content"]) for item in history) + len(body.message)
        > MAX_CONTEXT_CHARS
    ):
        history = history[2:]
    messages = history + [{"role": "user", "content": body.message}]

    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(503, "The server API key has not been configured.")
    try:
        with OpenAI(timeout=30.0, max_retries=0) as client:
            response = client.responses.create(
                model=MODEL,
                instructions=INSTRUCTIONS,
                input=messages,
                max_output_tokens=800,
                store=False,
            )
    except RateLimitError:
        raise HTTPException(429, "Usage limit reached. Please try later.")
    except APIError:
        # Do not expose provider error details, configuration, or secrets.
        raise HTTPException(502, "The model service could not answer. Try again.")

    reply = response.output_text.strip()
    if not reply or response.status not in ("completed", "incomplete"):
        raise HTTPException(502, "No usable answer was returned. Try again.")
    # Keep the browser's returned history within the schema bounds.
    clipped = len(reply) > 8_000
    reply = reply[:8_000]
    history = (messages + [{"role": "assistant", "content": reply}])[-8:]
    return {
        "reply": reply,
        "history": history,
        "incomplete": response.status == "incomplete" or clipped,
    }
