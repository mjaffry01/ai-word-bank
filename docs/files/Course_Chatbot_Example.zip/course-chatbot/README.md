# Course chatbot local demo

Read How to Create a Chatbot Chapters 6 and 7 and Appendix A for setup.
Install requirements.txt inside a virtual environment. Set OPENAI_API_KEY
securely in the server environment and OPENAI_MODEL to a model your account
can use (the example is gpt-4.1-mini). Run:

python -m uvicorn app:app --host 127.0.0.1 --port 8000

Open http://127.0.0.1:8000. API calls may incur charges. Never put a key
in the public frontend or repository. This demo has no login, persistent
history, retrieval, or local rate limiter. It is not a production deployment.

Validation: syntax and selected offline logic checks only; no live API call
or full framework integration test was performed while preparing this guide.
